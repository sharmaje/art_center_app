# ART Center Hospital Portal - Mobile App Design

## Screen List

1. **Splash/Loading Screen** — Initial app load with "Account Pending Approval" message for restricted users
2. **Staff Registration Screen** — Mandatory registration form for new users (online only)
3. **Dashboard/Home Screen** — Main navigation hub with access to all modules
4. **Patient Registration Screen** — Offline-first patient data entry with search capability
5. **Patient Search Screen** — Global search-as-you-type engine for patient lookup
6. **Patient Detail Screen** — View/edit patient information and medicine details
7. **Medicine Inventory Screen** — Stock tracking and inventory management
8. **Medicine Detail Screen** — Add/edit medicine batch, expiry, and quantities
9. **Sync Status Screen** — Display pending/synced data status
10. **Settings Screen** — User profile, logout, app settings

## Primary Content and Functionality

### Staff Registration Screen
- **Fields:** ART Center Name (dropdown), Full Name, Email, Designation (dropdown), WhatsApp Number
- **Validation:** Email pattern matching, phone number format (+92-XXX-XXXXXXX)
- **Behavior:** Submits to master Google Sheet, shows "Pending Approval" splash until admin approves
- **Data Source:** Dynamic dropdown populated from master Google Sheet

### Dashboard/Home Screen
- **Content:** Welcome message, quick access cards for main modules
- **Cards:** Patient Registration, Patient Search, Medicine Inventory, Sync Status
- **User Info:** Display logged-in user name and center name at top

### Patient Registration Screen
- **Form Fields:** Registration Number, PLHIV Number, Patient Name, Father/Husband Name, Contact Number, Address
- **Medicine Section:** Multi-selection array (1-3 ARV medicines), quantity inputs, "Add Custom Medicine" option
- **Offline Storage:** All data stored locally in SQLite with encryption
- **Sync Flag:** Metadata tracks sync_status as "Pending" or "Synced"

### Patient Search Screen
- **Search Bar:** Top-mounted, real-time filtering (<100ms latency)
- **Search Scope:** Searches across all patient attributes (name, PLHIV ID, registration number, contact)
- **Results:** Instant display of matching patients
- **Offline-First:** Works entirely without network

### Medicine Inventory Screen
- **List View:** Display all medicines with name, batch number, expiry date
- **Calculations:** Shows available balance = (opening + received) - daily consumption
- **Expiry Alerts:** Predictive 60-90 day expiry warning badge (high-visibility)
- **Add/Edit:** Floating action button to add new medicine entries

### Sync Status Screen
- **Pending Queue:** Shows all entries flagged as "Pending"
- **Synced History:** Shows recently synced entries
- **Manual Sync:** Button to trigger background sync process
- **Network Status:** Displays current connection state

## Key User Flows

### Flow 1: New Staff Registration
1. User opens app → Splash screen shown
2. Taps "Register" → Registration form appears
3. Fills form fields (ART Center from dropdown, name, email, designation, phone)
4. Submits → Data sent to master Google Sheet
5. Admin approves → User gains access to full app
6. User logs in → Dashboard appears

### Flow 2: Patient Registration & Medicine Entry
1. User taps "Patient Registration" on dashboard
2. Enters patient details (registration number, PLHIV ID, name, contact, address)
3. Selects 1-3 ARV medicines from dropdown
4. Enters quantity for each medicine
5. Optionally adds custom medicine
6. Saves → Data stored locally with sync_status = "Pending"
7. Background sync detects network → Sends to center's Google Sheet
8. Sync completes → sync_status = "Synced"

### Flow 3: Patient Search & Lookup
1. User taps "Patient Search" on dashboard
2. Types in search bar (name, PLHIV ID, or registration number)
3. Results filter in real-time
4. Taps patient → Detail screen opens
5. Can view/edit patient information
6. Changes saved locally and queued for sync

### Flow 4: Medicine Inventory Management
1. User taps "Medicine Inventory" on dashboard
2. Views list of all medicines with stock levels
3. Sees expiry alerts for medicines expiring in 60-90 days (red badge)
4. Taps medicine → Detail screen opens
5. Updates opening balance, received quantity, daily consumption
6. System auto-calculates available balance
7. Changes saved and synced

## Color Choices

- **Primary Color:** #0a7ea4 (Medical blue - trust, healthcare)
- **Background:** #ffffff (light), #151718 (dark)
- **Surface:** #f5f5f5 (light), #1e2022 (dark)
- **Foreground Text:** #11181C (light), #ECEDEE (dark)
- **Muted Text:** #687076 (light), #9BA1A6 (dark)
- **Success:** #22C55E (green - sync complete)
- **Warning:** #F59E0B (orange - expiry alert)
- **Error:** #EF4444 (red - sync failed)
- **Border:** #E5E7EB (light), #334155 (dark)

## Design Principles

- **Offline-First:** All critical data entry works without network
- **Mobile-Optimized:** Portrait orientation, one-handed usage, large touch targets
- **Accessibility:** High contrast, readable fonts, clear hierarchy
- **Clinical Context:** Professional appearance suitable for hospital environment
- **Data Security:** Encrypted local storage, secure sync protocols
- **Real-Time Feedback:** Instant search results, sync status indicators, validation messages
