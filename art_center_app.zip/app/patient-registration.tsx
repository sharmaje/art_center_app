import React, { useState } from "react";
import {
  ScrollView,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  FlatList,
  Modal,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { PatientFormData } from "@/lib/types";

const ARV_MEDICINES = [
  "TDF/FTC/EFV",
  "TDF/FTC/DTG",
  "ABC/3TC/EFV",
  "AZT/3TC/EFV",
  "PI-based regimen",
  "INSTI-based regimen",
];

export default function PatientRegistrationScreen() {
  const router = useRouter();
  const [formData, setFormData] = useState<PatientFormData>({
    registrationNumber: "",
    plhivNumber: "",
    patientName: "",
    fatherHusbandName: "",
    contactNumber: "",
    address: "",
    medicines: [],
  });

  const [selectedMedicines, setSelectedMedicines] = useState<string[]>([]);
  const [medicineQuantities, setMedicineQuantities] = useState<
    Record<string, string>
  >({});
  const [customMedicine, setCustomMedicine] = useState("");
  const [showMedicineModal, setShowMedicineModal] = useState(false);
  const [showCustomMedicineInput, setShowCustomMedicineInput] = useState(false);

  const handleAddMedicine = (medicine: string) => {
    if (selectedMedicines.length < 3 && !selectedMedicines.includes(medicine)) {
      setSelectedMedicines([...selectedMedicines, medicine]);
      setMedicineQuantities({ ...medicineQuantities, [medicine]: "0" });
      setShowMedicineModal(false);
    } else if (selectedMedicines.length >= 3) {
      Alert.alert("Limit Reached", "You can select maximum 3 medicines");
    }
  };

  const handleAddCustomMedicine = () => {
    if (customMedicine.trim()) {
      if (selectedMedicines.length < 3) {
        setSelectedMedicines([...selectedMedicines, customMedicine]);
        setMedicineQuantities({
          ...medicineQuantities,
          [customMedicine]: "0",
        });
        setCustomMedicine("");
        setShowCustomMedicineInput(false);
      } else {
        Alert.alert("Limit Reached", "You can select maximum 3 medicines");
      }
    }
  };

  const handleRemoveMedicine = (medicine: string) => {
    setSelectedMedicines(selectedMedicines.filter((m) => m !== medicine));
    const newQuantities = { ...medicineQuantities };
    delete newQuantities[medicine];
    setMedicineQuantities(newQuantities);
  };

  const handleSavePatient = () => {
    // Validation
    if (!formData.registrationNumber.trim()) {
      Alert.alert("Validation Error", "Registration Number is required");
      return;
    }
    if (!formData.plhivNumber.trim()) {
      Alert.alert("Validation Error", "PLHIV Number is required");
      return;
    }
    if (!formData.patientName.trim()) {
      Alert.alert("Validation Error", "Patient Name is required");
      return;
    }
    if (!formData.contactNumber.trim()) {
      Alert.alert("Validation Error", "Contact Number is required");
      return;
    }
    if (selectedMedicines.length === 0) {
      Alert.alert("Validation Error", "Please select at least one medicine");
      return;
    }

    // Create medicines array
    const medicines = selectedMedicines.map((medicine) => ({
      medicineName: medicine,
      quantity: parseInt(medicineQuantities[medicine] || "0"),
      isCustom: !ARV_MEDICINES.includes(medicine),
    }));

    // Save patient data (in real app, would save to database)
    console.log("Patient Data:", { ...formData, medicines });

    Alert.alert("Success", "Patient registered successfully", [
      {
        text: "OK",
        onPress: () => {
          router.back();
        },
      },
    ]);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-4">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-white text-base">← Back</Text>
          </TouchableOpacity>
          <Text className="text-white text-2xl font-bold mt-2">
            Patient Registration
          </Text>
        </View>

        {/* Form */}
        <View className="flex-1 px-6 py-6 gap-4">
          {/* Registration Number */}
          <View>
            <Text className="text-foreground font-semibold mb-2">
              Registration Number *
            </Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="Enter registration number"
              placeholderTextColor="#687076"
              value={formData.registrationNumber}
              onChangeText={(text) =>
                setFormData({ ...formData, registrationNumber: text })
              }
            />
          </View>

          {/* PLHIV Number */}
          <View>
            <Text className="text-foreground font-semibold mb-2">
              PLHIV Number *
            </Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="Enter PLHIV number"
              placeholderTextColor="#687076"
              value={formData.plhivNumber}
              onChangeText={(text) =>
                setFormData({ ...formData, plhivNumber: text })
              }
            />
          </View>

          {/* Patient Name */}
          <View>
            <Text className="text-foreground font-semibold mb-2">
              Patient Name *
            </Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="Enter patient name"
              placeholderTextColor="#687076"
              value={formData.patientName}
              onChangeText={(text) =>
                setFormData({ ...formData, patientName: text })
              }
            />
          </View>

          {/* Father/Husband Name */}
          <View>
            <Text className="text-foreground font-semibold mb-2">
              Father / Husband Name
            </Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="Enter father/husband name"
              placeholderTextColor="#687076"
              value={formData.fatherHusbandName}
              onChangeText={(text) =>
                setFormData({ ...formData, fatherHusbandName: text })
              }
            />
          </View>

          {/* Contact Number */}
          <View>
            <Text className="text-foreground font-semibold mb-2">
              Contact Number *
            </Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="Enter contact number"
              placeholderTextColor="#687076"
              keyboardType="phone-pad"
              value={formData.contactNumber}
              onChangeText={(text) =>
                setFormData({ ...formData, contactNumber: text })
              }
            />
          </View>

          {/* Address */}
          <View>
            <Text className="text-foreground font-semibold mb-2">Address</Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="Enter address"
              placeholderTextColor="#687076"
              multiline
              numberOfLines={3}
              value={formData.address}
              onChangeText={(text) =>
                setFormData({ ...formData, address: text })
              }
            />
          </View>

          {/* Medicines Section */}
          <View>
            <Text className="text-foreground font-semibold mb-2">
              ARV Medicines * ({selectedMedicines.length}/3)
            </Text>

            {/* Selected Medicines */}
            {selectedMedicines.length > 0 && (
              <View className="bg-surface rounded-lg p-3 mb-3 gap-2">
                {selectedMedicines.map((medicine, index) => (
                  <View
                    key={index}
                    className="flex-row items-center gap-2 bg-background rounded p-2"
                  >
                    <View className="flex-1">
                      <Text className="text-foreground text-sm font-medium">
                        {medicine}
                      </Text>
                      <TextInput
                        className="border border-border rounded px-2 py-1 mt-1 text-foreground bg-surface text-xs"
                        placeholder="Quantity"
                        placeholderTextColor="#687076"
                        keyboardType="number-pad"
                        value={medicineQuantities[medicine]}
                        onChangeText={(text) =>
                          setMedicineQuantities({
                            ...medicineQuantities,
                            [medicine]: text,
                          })
                        }
                      />
                    </View>
                    <TouchableOpacity
                      onPress={() => handleRemoveMedicine(medicine)}
                      className="bg-error rounded p-2"
                    >
                      <Text className="text-white text-xs font-bold">✕</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}

            {/* Add Medicine Buttons */}
            {selectedMedicines.length < 3 && (
              <View className="gap-2">
                <TouchableOpacity
                  onPress={() => setShowMedicineModal(true)}
                  className="bg-primary rounded-lg py-3 active:opacity-80"
                >
                  <Text className="text-white font-semibold text-center">
                    + Add Medicine
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setShowCustomMedicineInput(true)}
                  className="bg-surface border border-border rounded-lg py-3 active:opacity-80"
                >
                  <Text className="text-foreground font-semibold text-center">
                    + Add Custom Medicine
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          {/* Save Button */}
          <TouchableOpacity
            onPress={handleSavePatient}
            className="bg-success rounded-lg py-4 mt-6 active:opacity-80"
          >
            <Text className="text-white font-bold text-center text-base">
              Save Patient
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Medicine Selection Modal */}
      <Modal
        visible={showMedicineModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowMedicineModal(false)}
      >
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-2xl p-6 max-h-96">
            <Text className="text-foreground font-bold text-lg mb-4">
              Select Medicine
            </Text>
            <FlatList
              data={ARV_MEDICINES.filter(
                (m) => !selectedMedicines.includes(m)
              )}
              keyExtractor={(item) => item}
              renderItem={({ item }) => (
                <TouchableOpacity
                  onPress={() => handleAddMedicine(item)}
                  className="py-3 border-b border-border active:bg-surface"
                >
                  <Text className="text-foreground">{item}</Text>
                </TouchableOpacity>
              )}
            />
            <TouchableOpacity
              onPress={() => setShowMedicineModal(false)}
              className="bg-muted rounded-lg py-3 mt-4"
            >
              <Text className="text-white font-semibold text-center">
                Close
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Custom Medicine Input Modal */}
      <Modal
        visible={showCustomMedicineInput}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCustomMedicineInput(false)}
      >
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-2xl p-6">
            <Text className="text-foreground font-bold text-lg mb-4">
              Add Custom Medicine
            </Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface mb-4"
              placeholder="Enter medicine name"
              placeholderTextColor="#687076"
              value={customMedicine}
              onChangeText={setCustomMedicine}
              autoFocus
            />
            <View className="flex-row gap-2">
              <TouchableOpacity
                onPress={() => setShowCustomMedicineInput(false)}
                className="flex-1 bg-muted rounded-lg py-3"
              >
                <Text className="text-white font-semibold text-center">
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleAddCustomMedicine}
                className="flex-1 bg-primary rounded-lg py-3"
              >
                <Text className="text-white font-semibold text-center">
                  Add
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
