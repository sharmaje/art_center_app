import React, { useState } from "react";
import { ScrollView, Text, View, TouchableOpacity, Alert } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

export default function PatientDetailScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const patientData = params.patientData
    ? JSON.parse(params.patientData as string)
    : null;

  if (!patientData) {
    return (
      <ScreenContainer className="p-6 items-center justify-center">
        <Text className="text-foreground">Patient data not found</Text>
        <TouchableOpacity
          onPress={() => router.back()}
          className="mt-4 bg-primary px-6 py-3 rounded-lg"
        >
          <Text className="text-white font-semibold">Go Back</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const handleEdit = () => {
    Alert.alert("Edit Patient", "Edit functionality coming soon");
  };

  const handleDelete = () => {
    Alert.alert(
      "Delete Patient",
      "Are you sure you want to delete this patient record?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            Alert.alert("Success", "Patient deleted successfully", [
              { text: "OK", onPress: () => router.back() },
            ]);
          },
        },
      ]
    );
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-4">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-white text-base">← Back</Text>
          </TouchableOpacity>
          <Text className="text-white text-2xl font-bold mt-2">
            Patient Details
          </Text>
        </View>

        {/* Patient Information */}
        <View className="flex-1 px-6 py-6 gap-4">
          {/* Patient Name Card */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <Text className="text-muted text-xs font-semibold mb-1">
              PATIENT NAME
            </Text>
            <Text className="text-foreground text-xl font-bold">
              {patientData.patientName}
            </Text>
          </View>

          {/* Registration Details */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View>
              <Text className="text-muted text-xs font-semibold mb-1">
                REGISTRATION NUMBER
              </Text>
              <Text className="text-foreground font-medium">
                {patientData.registrationNumber}
              </Text>
            </View>
            <View className="border-t border-border pt-3">
              <Text className="text-muted text-xs font-semibold mb-1">
                PLHIV NUMBER
              </Text>
              <Text className="text-foreground font-medium">
                {patientData.plhivNumber}
              </Text>
            </View>
          </View>

          {/* Contact Information */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View>
              <Text className="text-muted text-xs font-semibold mb-1">
                CONTACT NUMBER
              </Text>
              <Text className="text-foreground font-medium">
                {patientData.contactNumber}
              </Text>
            </View>
          </View>

          {/* Current Medicines */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <Text className="text-muted text-xs font-semibold mb-3">
              CURRENT MEDICINES
            </Text>
            <View className="gap-2">
              {patientData.medicines && patientData.medicines.length > 0 ? (
                patientData.medicines.map((medicine: string, idx: number) => (
                  <View
                    key={idx}
                    className="bg-background rounded p-3 flex-row items-center"
                  >
                    <View className="flex-1">
                      <Text className="text-foreground font-medium">
                        {medicine}
                      </Text>
                    </View>
                    <Text className="text-primary font-bold">✓</Text>
                  </View>
                ))
              ) : (
                <Text className="text-muted text-sm">
                  No medicines recorded
                </Text>
              )}
            </View>
          </View>

          {/* Action Buttons */}
          <View className="gap-3 mt-6">
            <TouchableOpacity
              onPress={handleEdit}
              className="bg-primary rounded-lg py-4 active:opacity-80"
            >
              <Text className="text-white font-bold text-center text-base">
                Edit Patient
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleDelete}
              className="bg-error rounded-lg py-4 active:opacity-80"
            >
              <Text className="text-white font-bold text-center text-base">
                Delete Patient
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Footer with credits */}
        <View className="px-6 py-4 border-t border-border bg-surface">
          <Text className="text-muted text-xs text-center">
            Credits: Dr Neel Kanth MO Paeds HIV
          </Text>
          <Text className="text-muted text-xs text-center mt-1">
            Dr Ruth K.M Pfau Civil Hospital Karachi
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
