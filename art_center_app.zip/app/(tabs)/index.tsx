import { ScrollView, Text, View, TouchableOpacity, Image } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAppContext } from "@/lib/app-context";

export default function HomeScreen() {
  const router = useRouter();
  const { state } = useAppContext();

  const modules = [
    {
      id: "patient-registration",
      title: "Patient Registration",
      description: "Register new patients and manage their medicine details",
      icon: "👤",
      route: "/patient-registration",
    },
    {
      id: "patient-search",
      title: "Patient Search",
      description: "Search and view existing patient records",
      icon: "🔍",
      route: "/patient-search",
    },
    {
      id: "medicine-inventory",
      title: "Medicine Inventory",
      description: "Track medicine stock and expiry dates",
      icon: "💊",
      route: "/medicine-inventory",
    },
    {
      id: "sync-status",
      title: "Sync Status",
      description: "View pending and synced records",
      icon: "🔄",
      route: "/sync-status",
    },
  ];

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header with user info */}
        <View className="bg-primary px-6 pt-6 pb-8">
          <Text className="text-white text-3xl font-bold mb-2">
            ART Center Portal
          </Text>
          {state.currentUser && (
            <>
              <Text className="text-blue-100 text-base font-semibold">
                {state.currentUser.fullName}
              </Text>
              <Text className="text-blue-100 text-sm">
                {state.currentUser.artCenterName}
              </Text>
            </>
          )}
        </View>

        {/* Main content */}
        <View className="flex-1 px-6 py-8 gap-4">
          {/* Status indicator */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <Text className="text-foreground font-semibold mb-2">Status</Text>
            <View className="flex-row items-center gap-2">
              <View
                className={`w-3 h-3 rounded-full ${
                  state.syncStatus.isOnline ? "bg-success" : "bg-warning"
                }`}
              />
              <Text className="text-muted text-sm">
                {state.syncStatus.isOnline ? "Online" : "Offline"}
              </Text>
            </View>
            {state.syncStatus.pendingCount > 0 && (
              <Text className="text-warning text-xs mt-2">
                {state.syncStatus.pendingCount} pending sync
              </Text>
            )}
          </View>

          {/* Module cards */}
          <View className="gap-3">
            {modules.map((module) => (
              <TouchableOpacity
                key={module.id}
                onPress={() => router.push(module.route as any)}
                className="bg-surface rounded-lg p-4 border border-border active:opacity-70"
              >
                <View className="flex-row items-start gap-3">
                  <Text className="text-3xl">{module.icon}</Text>
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold text-base">
                      {module.title}
                    </Text>
                    <Text className="text-muted text-sm mt-1">
                      {module.description}
                    </Text>
                  </View>
                  <Text className="text-muted">→</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Footer with credits */}
        <View className="px-6 py-6 border-t border-border mt-8">
          <Text className="text-muted text-xs text-center leading-relaxed">
            Credits: Dr Neel Kanth MO Paeds HIV
          </Text>
          <Text className="text-muted text-xs text-center mt-1">
            Dr Ruth K.M Pfau Civil Hospital Karachi
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
