import React, { useState } from "react";
import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

export default function MedicineDetailScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const medicineData = params.medicineData
    ? JSON.parse(params.medicineData as string)
    : null;

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    openingBalance: medicineData?.openingBalance.toString() || "0",
    receivedFromOffice: medicineData?.receivedFromOffice.toString() || "0",
    dailyConsumption: medicineData?.dailyConsumption.toString() || "0",
  });

  if (!medicineData) {
    return (
      <ScreenContainer className="p-6 items-center justify-center">
        <Text className="text-foreground">Medicine data not found</Text>
        <TouchableOpacity
          onPress={() => router.back()}
          className="mt-4 bg-primary px-6 py-3 rounded-lg"
        >
          <Text className="text-white font-semibold">Go Back</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const handleSave = () => {
    Alert.alert("Success", "Medicine inventory updated successfully", [
      {
        text: "OK",
        onPress: () => {
          setIsEditing(false);
        },
      },
    ]);
  };

  const handleDelete = () => {
    Alert.alert(
      "Delete Medicine",
      "Are you sure you want to delete this medicine record?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            Alert.alert("Success", "Medicine deleted successfully", [
              { text: "OK", onPress: () => router.back() },
            ]);
          },
        },
      ]
    );
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-4">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-white text-base">← Back</Text>
          </TouchableOpacity>
          <Text className="text-white text-2xl font-bold mt-2">
            Medicine Details
          </Text>
        </View>

        {/* Medicine Information */}
        <View className="flex-1 px-6 py-6 gap-4">
          {/* Medicine Name Card */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <Text className="text-muted text-xs font-semibold mb-1">
              MEDICINE NAME
            </Text>
            <Text className="text-foreground text-xl font-bold">
              {medicineData.medicineName}
            </Text>
          </View>

          {/* Basic Details */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <View>
              <Text className="text-muted text-xs font-semibold mb-1">
                BATCH NUMBER
              </Text>
              <Text className="text-foreground font-medium">
                {medicineData.batchNumber}
              </Text>
            </View>
            <View className="border-t border-border pt-3">
              <Text className="text-muted text-xs font-semibold mb-1">
                EXPIRY DATE
              </Text>
              <Text className="text-foreground font-medium">
                {medicineData.expiryDate
                  ? new Date(medicineData.expiryDate).toLocaleDateString()
                  : "N/A"}
              </Text>
              {medicineData.isExpired && (
                <Text className="text-error text-xs font-bold mt-1">
                  ⚠️ This medicine has expired
                </Text>
              )}
              {medicineData.isExpiringSoon && !medicineData.isExpired && (
                <Text className="text-warning text-xs font-bold mt-1">
                  ⚠️ Expires in {medicineData.daysToExpiry} days
                </Text>
              )}
            </View>
          </View>

          {/* Stock Information */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <View className="flex-row justify-between items-center mb-4">
              <Text className="text-foreground font-semibold">
                Stock Information
              </Text>
              {!isEditing && (
                <TouchableOpacity onPress={() => setIsEditing(true)}>
                  <Text className="text-primary font-semibold text-sm">
                    Edit
                  </Text>
                </TouchableOpacity>
              )}
            </View>

            {isEditing ? (
              <View className="gap-3">
                {/* Opening Balance */}
                <View>
                  <Text className="text-muted text-xs font-semibold mb-1">
                    Opening Balance
                  </Text>
                  <TextInput
                    className="border border-border rounded-lg px-3 py-2 text-foreground bg-background"
                    keyboardType="number-pad"
                    value={formData.openingBalance}
                    onChangeText={(text) =>
                      setFormData({ ...formData, openingBalance: text })
                    }
                  />
                </View>

                {/* Received from Office */}
                <View>
                  <Text className="text-muted text-xs font-semibold mb-1">
                    Received from Office
                  </Text>
                  <TextInput
                    className="border border-border rounded-lg px-3 py-2 text-foreground bg-background"
                    keyboardType="number-pad"
                    value={formData.receivedFromOffice}
                    onChangeText={(text) =>
                      setFormData({ ...formData, receivedFromOffice: text })
                    }
                  />
                </View>

                {/* Daily Consumption */}
                <View>
                  <Text className="text-muted text-xs font-semibold mb-1">
                    Daily Consumption
                  </Text>
                  <TextInput
                    className="border border-border rounded-lg px-3 py-2 text-foreground bg-background"
                    keyboardType="number-pad"
                    value={formData.dailyConsumption}
                    onChangeText={(text) =>
                      setFormData({ ...formData, dailyConsumption: text })
                    }
                  />
                </View>

                {/* Action Buttons */}
                <View className="flex-row gap-2 mt-4">
                  <TouchableOpacity
                    onPress={() => setIsEditing(false)}
                    className="flex-1 bg-muted rounded-lg py-3"
                  >
                    <Text className="text-white font-semibold text-center">
                      Cancel
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={handleSave}
                    className="flex-1 bg-success rounded-lg py-3"
                  >
                    <Text className="text-white font-semibold text-center">
                      Save
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <View className="gap-2">
                <View className="flex-row justify-between bg-background rounded p-2">
                  <Text className="text-muted text-sm">Opening Balance:</Text>
                  <Text className="text-foreground font-semibold">
                    {medicineData.openingBalance}
                  </Text>
                </View>
                <View className="flex-row justify-between bg-background rounded p-2">
                  <Text className="text-muted text-sm">Received:</Text>
                  <Text className="text-foreground font-semibold">
                    +{medicineData.receivedFromOffice}
                  </Text>
                </View>
                <View className="flex-row justify-between bg-background rounded p-2">
                  <Text className="text-muted text-sm">Daily Consumption:</Text>
                  <Text className="text-foreground font-semibold">
                    -{medicineData.dailyConsumption}
                  </Text>
                </View>
                <View className="border-t border-border pt-2 mt-2 flex-row justify-between bg-primary/10 rounded p-2">
                  <Text className="text-foreground font-semibold">
                    Available Balance:
                  </Text>
                  <Text className="text-primary font-bold text-lg">
                    {medicineData.availableBalance}
                  </Text>
                </View>
              </View>
            )}
          </View>

          {/* Action Buttons */}
          {!isEditing && (
            <View className="gap-3 mt-6">
              <TouchableOpacity
                onPress={handleDelete}
                className="bg-error rounded-lg py-4 active:opacity-80"
              >
                <Text className="text-white font-bold text-center text-base">
                  Delete Medicine
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Footer with credits */}
        <View className="px-6 py-4 border-t border-border bg-surface">
          <Text className="text-muted text-xs text-center">
            Credits: Dr Neel Kanth MO Paeds HIV
          </Text>
          <Text className="text-muted text-xs text-center mt-1">
            Dr Ruth K.M Pfau Civil Hospital Karachi
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
