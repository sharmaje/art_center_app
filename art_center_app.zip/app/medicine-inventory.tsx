import React, { useState, useMemo } from "react";
import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  FlatList,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

// Mock medicine inventory data
const MOCK_MEDICINES = [
  {
    id: "1",
    medicineName: "TDF/FTC/EFV",
    batchNumber: "BATCH001",
    expiryDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), // 45 days
    openingBalance: 100,
    receivedFromOffice: 50,
    dailyConsumption: 5,
  },
  {
    id: "2",
    medicineName: "TDF/FTC/DTG",
    batchNumber: "BATCH002",
    expiryDate: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000), // 120 days
    openingBalance: 80,
    receivedFromOffice: 30,
    dailyConsumption: 3,
  },
  {
    id: "3",
    medicineName: "ABC/3TC/EFV",
    batchNumber: "BATCH003",
    expiryDate: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000), // 75 days
    openingBalance: 60,
    receivedFromOffice: 20,
    dailyConsumption: 2,
  },
  {
    id: "4",
    medicineName: "AZT/3TC/EFV",
    batchNumber: "BATCH004",
    expiryDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // Expired
    openingBalance: 40,
    receivedFromOffice: 10,
    dailyConsumption: 1,
  },
];

function calculateDaysToExpiry(expiryDate: Date): number {
  const today = new Date();
  const diffTime = expiryDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

function isExpiringSoon(expiryDate: Date): boolean {
  const daysToExpiry = calculateDaysToExpiry(expiryDate);
  return daysToExpiry >= 0 && daysToExpiry <= 90;
}

function isExpired(expiryDate: Date): boolean {
  return calculateDaysToExpiry(expiryDate) < 0;
}

export default function MedicineInventoryScreen() {
  const router = useRouter();
  const [medicines] = useState(MOCK_MEDICINES);

  const medicinesWithCalculations = useMemo(() => {
    return medicines.map((med) => ({
      ...med,
      availableBalance:
        med.openingBalance + med.receivedFromOffice - med.dailyConsumption,
      daysToExpiry: calculateDaysToExpiry(med.expiryDate),
      isExpiringSoon: isExpiringSoon(med.expiryDate),
      isExpired: isExpired(med.expiryDate),
    }));
  }, [medicines]);

  const expiringMedicines = medicinesWithCalculations.filter(
    (m) => m.isExpiringSoon && !m.isExpired
  );
  const expiredMedicines = medicinesWithCalculations.filter((m) => m.isExpired);

  const handleAddMedicine = () => {
    Alert.alert("Add Medicine", "Add medicine functionality coming soon");
  };

  const handleMedicinePress = (medicine: (typeof medicinesWithCalculations)[0]) => {
    router.push({
      pathname: "/medicine-detail",
      params: { medicineId: medicine.id, medicineData: JSON.stringify(medicine) },
    });
  };

  const MedicineCard = ({
    medicine,
  }: {
    medicine: (typeof medicinesWithCalculations)[0];
  }) => (
    <TouchableOpacity
      onPress={() => handleMedicinePress(medicine)}
      className="bg-surface rounded-lg p-4 border border-border mb-3 active:opacity-70"
    >
      <View className="gap-3">
        {/* Header */}
        <View className="flex-row justify-between items-start">
          <View className="flex-1">
            <Text className="text-foreground font-semibold text-base">
              {medicine.medicineName}
            </Text>
            <Text className="text-muted text-xs mt-1">
              Batch: {medicine.batchNumber}
            </Text>
          </View>
          {medicine.isExpired && (
            <View className="bg-error rounded px-2 py-1">
              <Text className="text-white text-xs font-bold">EXPIRED</Text>
            </View>
          )}
          {medicine.isExpiringSoon && !medicine.isExpired && (
            <View className="bg-warning rounded px-2 py-1">
              <Text className="text-white text-xs font-bold">⚠ ALERT</Text>
            </View>
          )}
        </View>

        {/* Stock Information */}
        <View className="bg-background rounded p-2 gap-1">
          <View className="flex-row justify-between">
            <Text className="text-muted text-xs">Opening Balance:</Text>
            <Text className="text-foreground font-medium text-xs">
              {medicine.openingBalance}
            </Text>
          </View>
          <View className="flex-row justify-between">
            <Text className="text-muted text-xs">Received:</Text>
            <Text className="text-foreground font-medium text-xs">
              +{medicine.receivedFromOffice}
            </Text>
          </View>
          <View className="flex-row justify-between border-t border-border pt-1 mt-1">
            <Text className="text-muted text-xs">Daily Consumption:</Text>
            <Text className="text-foreground font-medium text-xs">
              -{medicine.dailyConsumption}
            </Text>
          </View>
        </View>

        {/* Available Balance */}
        <View className="bg-primary/10 rounded p-2 flex-row justify-between items-center">
          <Text className="text-muted text-xs font-semibold">
            Available Balance:
          </Text>
          <Text className="text-primary font-bold text-base">
            {medicine.availableBalance}
          </Text>
        </View>

        {/* Expiry Information */}
        <View className="flex-row justify-between items-center">
          <Text className="text-muted text-xs">
            Expires: {medicine.expiryDate.toLocaleDateString()}
          </Text>
          <Text
            className={`text-xs font-semibold ${
              medicine.isExpired
                ? "text-error"
                : medicine.isExpiringSoon
                  ? "text-warning"
                  : "text-success"
            }`}
          >
            {medicine.isExpired
              ? "Expired"
              : `${medicine.daysToExpiry} days left`}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-4">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-white text-base">← Back</Text>
          </TouchableOpacity>
          <Text className="text-white text-2xl font-bold mt-2">
            Medicine Inventory
          </Text>
        </View>

        {/* Content */}
        <View className="flex-1 px-6 py-6">
          {/* Alert Summary */}
          {(expiringMedicines.length > 0 || expiredMedicines.length > 0) && (
            <View className="bg-warning/10 border border-warning rounded-lg p-4 mb-6">
              {expiredMedicines.length > 0 && (
                <Text className="text-error font-semibold text-sm mb-2">
                  🚨 {expiredMedicines.length} expired medicine
                  {expiredMedicines.length !== 1 ? "s" : ""}
                </Text>
              )}
              {expiringMedicines.length > 0 && (
                <Text className="text-warning font-semibold text-sm">
                  ⚠️ {expiringMedicines.length} medicine
                  {expiringMedicines.length !== 1 ? "s" : ""} expiring soon
                  (60-90 days)
                </Text>
              )}
            </View>
          )}

          {/* Medicines List */}
          <FlatList
            data={medicinesWithCalculations}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <MedicineCard medicine={item} />}
            scrollEnabled={false}
            contentContainerStyle={{ flexGrow: 1 }}
            ListEmptyComponent={
              <View className="items-center justify-center py-8">
                <Text className="text-muted">No medicines in inventory</Text>
              </View>
            }
            ListFooterComponent={
              <TouchableOpacity
                onPress={handleAddMedicine}
                className="bg-primary rounded-lg py-4 mt-6 active:opacity-80"
              >
                <Text className="text-white font-bold text-center text-base">
                  + Add Medicine
                </Text>
              </TouchableOpacity>
            }
          />
        </View>

        {/* Footer with credits */}
        <View className="px-6 py-4 border-t border-border bg-surface">
          <Text className="text-muted text-xs text-center">
            Credits: Dr Neel Kanth MO Paeds HIV
          </Text>
          <Text className="text-muted text-xs text-center mt-1">
            Dr Ruth K.M Pfau Civil Hospital Karachi
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
