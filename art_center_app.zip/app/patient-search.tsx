import React, { useState, useMemo } from "react";
import {
  ScrollView,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  FlatList,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

// Mock patient data for demonstration
const MOCK_PATIENTS = [
  {
    id: "1",
    registrationNumber: "REG001",
    plhivNumber: "PL001",
    patientName: "Ahmed Hassan",
    contactNumber: "03001234567",
    medicines: ["TDF/FTC/EFV"],
  },
  {
    id: "2",
    registrationNumber: "REG002",
    plhivNumber: "PL002",
    patientName: "Fatima Khan",
    contactNumber: "03009876543",
    medicines: ["TDF/FTC/DTG"],
  },
  {
    id: "3",
    registrationNumber: "REG003",
    plhivNumber: "PL003",
    patientName: "Muhammad Ali",
    contactNumber: "03005555555",
    medicines: ["ABC/3TC/EFV", "PI-based regimen"],
  },
  {
    id: "4",
    registrationNumber: "REG004",
    plhivNumber: "PL004",
    patientName: "Aisha Ahmed",
    contactNumber: "03003333333",
    medicines: ["AZT/3TC/EFV"],
  },
  {
    id: "5",
    registrationNumber: "REG005",
    plhivNumber: "PL005",
    patientName: "Hassan Ahmed",
    contactNumber: "03007777777",
    medicines: ["TDF/FTC/EFV", "INSTI-based regimen"],
  },
];

export default function PatientSearchScreen() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");

  // Real-time search filtering
  const filteredPatients = useMemo(() => {
    if (!searchQuery.trim()) return [];

    const query = searchQuery.toLowerCase();
    return MOCK_PATIENTS.filter(
      (patient) =>
        patient.patientName.toLowerCase().includes(query) ||
        patient.registrationNumber.toLowerCase().includes(query) ||
        patient.plhivNumber.toLowerCase().includes(query) ||
        patient.contactNumber.includes(query)
    );
  }, [searchQuery]);

  const handlePatientSelect = (patient: (typeof MOCK_PATIENTS)[0]) => {
    router.push({
      pathname: "/patient-detail",
      params: { patientId: patient.id, patientData: JSON.stringify(patient) },
    });
  };

  return (
    <ScreenContainer className="p-0">
      {/* Header */}
      <View className="bg-primary px-6 py-4">
        <TouchableOpacity onPress={() => router.back()}>
          <Text className="text-white text-base">← Back</Text>
        </TouchableOpacity>
        <Text className="text-white text-2xl font-bold mt-2">
          Patient Search
        </Text>
      </View>

      {/* Search Bar */}
      <View className="px-6 py-4 bg-surface border-b border-border">
        <TextInput
          className="border border-border rounded-lg px-4 py-3 text-foreground bg-background"
          placeholder="Search by name, ID, or contact..."
          placeholderTextColor="#687076"
          value={searchQuery}
          onChangeText={setSearchQuery}
          autoFocus
        />
        <Text className="text-muted text-xs mt-2">
          Search across all attributes in real-time
        </Text>
      </View>

      {/* Results */}
      <View className="flex-1">
        {searchQuery.trim() === "" ? (
          <View className="flex-1 items-center justify-center px-6">
            <Text className="text-muted text-base text-center">
              Start typing to search for patients
            </Text>
          </View>
        ) : filteredPatients.length === 0 ? (
          <View className="flex-1 items-center justify-center px-6">
            <Text className="text-muted text-base text-center">
              No patients found matching "{searchQuery}"
            </Text>
          </View>
        ) : (
          <FlatList
            data={filteredPatients}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => handlePatientSelect(item)}
                className="px-6 py-4 border-b border-border bg-surface active:bg-background"
              >
                <View className="gap-2">
                  <View className="flex-row justify-between items-start">
                    <View className="flex-1">
                      <Text className="text-foreground font-semibold text-base">
                        {item.patientName}
                      </Text>
                      <Text className="text-muted text-xs mt-1">
                        Reg: {item.registrationNumber} | PLHIV: {item.plhivNumber}
                      </Text>
                    </View>
                    <Text className="text-muted">→</Text>
                  </View>
                  <Text className="text-muted text-xs">
                    📞 {item.contactNumber}
                  </Text>
                  <View className="flex-row flex-wrap gap-1 mt-1">
                    {item.medicines.map((med, idx) => (
                      <View key={idx} className="bg-primary/20 rounded px-2 py-1">
                        <Text className="text-primary text-xs font-medium">
                          {med}
                        </Text>
                      </View>
                    ))}
                  </View>
                </View>
              </TouchableOpacity>
            )}
            contentContainerStyle={{ flexGrow: 1 }}
            ListFooterComponent={
              filteredPatients.length > 0 ? (
                <View className="px-6 py-4">
                  <Text className="text-muted text-xs text-center">
                    Found {filteredPatients.length} patient
                    {filteredPatients.length !== 1 ? "s" : ""}
                  </Text>
                </View>
              ) : null
            }
          />
        )}
      </View>

      {/* Footer with credits */}
      <View className="px-6 py-4 border-t border-border bg-surface">
        <Text className="text-muted text-xs text-center">
          Credits: Dr Neel Kanth MO Paeds HIV
        </Text>
        <Text className="text-muted text-xs text-center mt-1">
          Dr Ruth K.M Pfau Civil Hospital Karachi
        </Text>
      </View>
    </ScreenContainer>
  );
}
