import React, { useState } from "react";
import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  FlatList,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

// Mock sync queue data
const MOCK_SYNC_QUEUE = [
  {
    id: "1",
    entityType: "patient",
    entityId: "patient-1",
    action: "create",
    description: "Patient: Ahmed Hassan",
    syncStatus: "Pending",
    createdAt: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
  },
  {
    id: "2",
    entityType: "medicine",
    entityId: "med-1",
    action: "update",
    description: "Medicine: TDF/FTC/EFV - Batch BATCH001",
    syncStatus: "Pending",
    createdAt: new Date(Date.now() - 2 * 60 * 1000), // 2 minutes ago
  },
  {
    id: "3",
    entityType: "patient",
    entityId: "patient-2",
    action: "create",
    description: "Patient: Fatima Khan",
    syncStatus: "Synced",
    createdAt: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
  },
  {
    id: "4",
    entityType: "medicine",
    entityId: "med-2",
    action: "create",
    description: "Medicine: ABC/3TC/EFV - Batch BATCH003",
    syncStatus: "Synced",
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
  },
];

function formatTime(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${diffDays}d ago`;
}

export default function SyncStatusScreen() {
  const router = useRouter();
  const [syncQueue] = useState(MOCK_SYNC_QUEUE);
  const [isSyncing, setIsSyncing] = useState(false);

  const pendingItems = syncQueue.filter((item) => item.syncStatus === "Pending");
  const syncedItems = syncQueue.filter((item) => item.syncStatus === "Synced");

  const handleManualSync = () => {
    if (pendingItems.length === 0) {
      Alert.alert("No Pending Items", "All data is already synced");
      return;
    }

    setIsSyncing(true);
    // Simulate sync process
    setTimeout(() => {
      setIsSyncing(false);
      Alert.alert(
        "Sync Complete",
        `Successfully synced ${pendingItems.length} item${pendingItems.length !== 1 ? "s" : ""}`
      );
    }, 2000);
  };

  const SyncItem = ({
    item,
  }: {
    item: (typeof MOCK_SYNC_QUEUE)[0];
  }) => (
    <View className="bg-surface rounded-lg p-4 border border-border mb-2">
      <View className="flex-row justify-between items-start mb-2">
        <View className="flex-1">
          <Text className="text-foreground font-semibold">
            {item.description}
          </Text>
          <Text className="text-muted text-xs mt-1">
            {item.action === "create"
              ? "Created"
              : item.action === "update"
                ? "Updated"
                : "Deleted"}
          </Text>
        </View>
        <View
          className={`rounded px-2 py-1 ${
            item.syncStatus === "Synced"
              ? "bg-success/20"
              : "bg-warning/20"
          }`}
        >
          <Text
            className={`text-xs font-bold ${
              item.syncStatus === "Synced"
                ? "text-success"
                : "text-warning"
            }`}
          >
            {item.syncStatus === "Synced" ? "✓ Synced" : "⏳ Pending"}
          </Text>
        </View>
      </View>
      <Text className="text-muted text-xs">
        {formatTime(item.createdAt)}
      </Text>
    </View>
  );

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-4">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-white text-base">← Back</Text>
          </TouchableOpacity>
          <Text className="text-white text-2xl font-bold mt-2">
            Sync Status
          </Text>
        </View>

        {/* Content */}
        <View className="flex-1 px-6 py-6">
          {/* Status Summary */}
          <View className="bg-surface rounded-lg p-4 border border-border mb-6">
            <View className="flex-row justify-between mb-3">
              <View>
                <Text className="text-muted text-xs font-semibold">
                  PENDING
                </Text>
                <Text className="text-warning text-2xl font-bold mt-1">
                  {pendingItems.length}
                </Text>
              </View>
              <View>
                <Text className="text-muted text-xs font-semibold">
                  SYNCED
                </Text>
                <Text className="text-success text-2xl font-bold mt-1">
                  {syncedItems.length}
                </Text>
              </View>
              <View>
                <Text className="text-muted text-xs font-semibold">
                  TOTAL
                </Text>
                <Text className="text-foreground text-2xl font-bold mt-1">
                  {syncQueue.length}
                </Text>
              </View>
            </View>
          </View>

          {/* Manual Sync Button */}
          <TouchableOpacity
            onPress={handleManualSync}
            disabled={isSyncing}
            className={`rounded-lg py-4 mb-6 active:opacity-80 ${
              isSyncing ? "bg-muted" : "bg-primary"
            }`}
          >
            <Text className="text-white font-bold text-center text-base">
              {isSyncing ? "🔄 Syncing..." : "🔄 Sync Now"}
            </Text>
          </TouchableOpacity>

          {/* Pending Items */}
          {pendingItems.length > 0 && (
            <View className="mb-6">
              <Text className="text-foreground font-semibold text-base mb-3">
                ⏳ Pending ({pendingItems.length})
              </Text>
              <FlatList
                data={pendingItems}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => <SyncItem item={item} />}
                scrollEnabled={false}
              />
            </View>
          )}

          {/* Synced Items */}
          {syncedItems.length > 0 && (
            <View>
              <Text className="text-foreground font-semibold text-base mb-3">
                ✓ Synced ({syncedItems.length})
              </Text>
              <FlatList
                data={syncedItems}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => <SyncItem item={item} />}
                scrollEnabled={false}
              />
            </View>
          )}

          {syncQueue.length === 0 && (
            <View className="items-center justify-center py-8">
              <Text className="text-muted text-base">
                No sync history available
              </Text>
            </View>
          )}
        </View>

        {/* Footer with credits */}
        <View className="px-6 py-4 border-t border-border bg-surface">
          <Text className="text-muted text-xs text-center">
            Credits: Dr Neel Kanth MO Paeds HIV
          </Text>
          <Text className="text-muted text-xs text-center mt-1">
            Dr Ruth K.M Pfau Civil Hospital Karachi
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
