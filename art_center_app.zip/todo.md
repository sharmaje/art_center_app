# ART Center Hospital Portal - Development TODO

## Core Features

### Module 1: Staff Registration & Access Control
- [x] Create registration form screen with validation
- [ ] Implement ART Center dropdown (dynamic from master sheet)
- [ ] Add email validation (clinical/verified patterns)
- [ ] Add WhatsApp phone number validation (+92-XXX-XXXXXXX)
- [ ] Implement "Account Pending Approval" splash screen
- [ ] Create access status system (Pending, Allowed, Rejected)
- [ ] Implement local encryption keys for allowed users

### Module 2: Dashboard & Navigation
- [x] Create main dashboard/home screen
- [x] Add navigation cards (Patient Registration, Search, Inventory, Sync)
- [x] Display user info (name, center name) at top
- [x] Create quick access cards for each module
- [ ] Add logout functionality

### Module 3: Patient Registration & Search (Offline-First)
- [x] Create patient registration form
- [x] Implement fields: Registration Number, PLHIV Number, Patient Name, Father/Husband Name, Contact, Address
- [ ] Add local encryption for sensitive patient data
- [x] Implement medicine multi-selection array (1-3 medicines)
- [x] Add quantity input for each medicine
- [x] Implement "Add Custom Medicine" option
- [x] Create search-as-you-type engine (<100ms latency)
- [x] Implement real-time filtering across all attributes
- [x] Add patient detail/edit screen
- [ ] Implement local SQLite database for patient storage
- [ ] Add sync_status metadata tracking

### Module 4: Medicine Inventory & Stock Management
- [x] Create medicine inventory list screen
- [ ] Implement medicine entry form (name, batch number, expiry date)
- [ ] Add calendar date picker for expiry dates
- [x] Implement inventory calculations: Available Balance = (Opening + Received) - Daily Consumption
- [x] Create predictive 60-90 day expiry alert system
- [x] Add high-visibility warning badge for expiring medicines
- [x] Implement medicine detail/edit screen
- [x] Add stock tracking with opening balance, received, consumption fields

### Module 5: Synchronization Engine
- [ ] Implement persistent network listener
- [ ] Create background sync service
- [ ] Add metadata flag system (sync_status = 'Pending' or 'Synced')
- [ ] Implement network polling for active connection
- [ ] Create sequential HTTP POST streams to Google Sheet API
- [x] Add sync status screen showing pending/synced entries
- [ ] Implement data conflict resolution
- [x] Add manual sync trigger button

### UI/UX & Polish
- [x] Create app logo and branding assets
- [x] Update app.config.ts with app name and branding
- [x] Implement theme colors (medical blue primary)
- [x] Add footer credit: "Credits: Dr Neel Kanth MO Paeds HIV (Dr Ruth K.M Pfau Civil Hospital Karachi)"
- [x] Ensure responsive design for various screen sizes
- [ ] Add loading states and spinners
- [ ] Implement error handling and user feedback
- [ ] Add haptic feedback for interactions
- [ ] Create smooth transitions between screens

### Testing & Validation
- [ ] Test offline functionality
- [ ] Test sync with network reconnection
- [ ] Test data encryption/decryption
- [ ] Test search performance (<100ms)
- [ ] Test form validation
- [ ] Test access control (Pending/Allowed/Rejected)
- [ ] Test expiry alert system
- [ ] Test on iOS and Android

## Completed Features
(Items will be moved here as they are completed)
