import { sql } from "drizzle-orm";
import { sqliteTable, text, integer, real, primaryKey } from "drizzle-orm/sqlite-core";

// Users table for staff registration
export const users = sqliteTable("users", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  artCenterName: text("art_center_name").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  designation: text("designation").notNull(), // Medical Officer, Data Manager, Counselor
  whatsappNumber: text("whatsapp_number").notNull(),
  accessStatus: text("access_status").notNull().default("Pending"), // Pending, Allowed, Rejected
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
  updatedAt: integer("updated_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});

// Patients table for patient registration
export const patients = sqliteTable("patients", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  registrationNumber: text("registration_number").notNull().unique(),
  plhivNumber: text("plhiv_number").notNull(),
  patientName: text("patient_name").notNull(),
  fatherHusbandName: text("father_husband_name"),
  contactNumber: text("contact_number").notNull(),
  address: text("address"),
  userId: text("user_id").notNull(), // Reference to user who registered
  syncStatus: text("sync_status").notNull().default("Pending"), // Pending, Synced
  syncedAt: integer("synced_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
  updatedAt: integer("updated_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});

// Patient medicines table for multi-selection medicines
export const patientMedicines = sqliteTable("patient_medicines", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  patientId: text("patient_id").notNull(),
  medicineName: text("medicine_name").notNull(),
  quantity: integer("quantity").notNull().default(0),
  isCustom: integer("is_custom", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});

// Medicine inventory table for stock management
export const medicineInventory = sqliteTable("medicine_inventory", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  medicineName: text("medicine_name").notNull(),
  batchNumber: text("batch_number").notNull(),
  expiryDate: integer("expiry_date", { mode: "timestamp" }).notNull(),
  openingBalance: integer("opening_balance").notNull().default(0),
  receivedFromOffice: integer("received_from_office").notNull().default(0),
  dailyConsumption: integer("daily_consumption").notNull().default(0),
  userId: text("user_id").notNull(), // Reference to user who manages inventory
  syncStatus: text("sync_status").notNull().default("Pending"), // Pending, Synced
  syncedAt: integer("synced_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
  updatedAt: integer("updated_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});

// Sync queue table to track pending syncs
export const syncQueue = sqliteTable("sync_queue", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  entityType: text("entity_type").notNull(), // patient, medicine
  entityId: text("entity_id").notNull(),
  action: text("action").notNull(), // create, update, delete
  payload: text("payload").notNull(), // JSON stringified data
  syncStatus: text("sync_status").notNull().default("Pending"), // Pending, Synced, Failed
  retryCount: integer("retry_count").notNull().default(0),
  lastError: text("last_error"),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
  syncedAt: integer("synced_at", { mode: "timestamp" }),
});

// Master medicines list for dropdowns
export const masterMedicines = sqliteTable("master_medicines", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  medicineName: text("medicine_name").notNull().unique(),
  category: text("category"), // ARV, Supportive, etc.
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});

// Master ART centers list
export const masterArtCenters = sqliteTable("master_art_centers", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  centerName: text("center_name").notNull().unique(),
  googleSheetUrl: text("google_sheet_url"),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`CURRENT_TIMESTAMP`),
});
