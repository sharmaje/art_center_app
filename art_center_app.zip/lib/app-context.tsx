import React, { createContext, useContext, useReducer, ReactNode } from "react";
import { User, SyncStatus } from "./types";

interface AppState {
  currentUser: User | null;
  isLoading: boolean;
  accessStatus: "Pending" | "Allowed" | "Rejected" | null;
  syncStatus: SyncStatus;
  error: string | null;
}

type AppAction =
  | { type: "SET_USER"; payload: User }
  | { type: "CLEAR_USER" }
  | { type: "SET_ACCESS_STATUS"; payload: "Pending" | "Allowed" | "Rejected" }
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_SYNC_STATUS"; payload: SyncStatus }
  | { type: "SET_ERROR"; payload: string | null }
  | { type: "RESET" };

const initialState: AppState = {
  currentUser: null,
  isLoading: false,
  accessStatus: null,
  syncStatus: {
    pendingCount: 0,
    syncedCount: 0,
    failedCount: 0,
    isOnline: false,
    isSyncing: false,
  },
  error: null,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case "SET_USER":
      return { ...state, currentUser: action.payload };
    case "CLEAR_USER":
      return { ...state, currentUser: null };
    case "SET_ACCESS_STATUS":
      return { ...state, accessStatus: action.payload };
    case "SET_LOADING":
      return { ...state, isLoading: action.payload };
    case "SET_SYNC_STATUS":
      return { ...state, syncStatus: action.payload };
    case "SET_ERROR":
      return { ...state, error: action.payload };
    case "RESET":
      return initialState;
    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useAppContext must be used within AppProvider");
  }
  return context;
}
