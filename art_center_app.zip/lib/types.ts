// User types
export interface User {
  id: string;
  artCenterName: string;
  fullName: string;
  email: string;
  designation: "Medical Officer" | "Data Manager" | "Counselor";
  whatsappNumber: string;
  accessStatus: "Pending" | "Allowed" | "Rejected";
  createdAt: Date;
  updatedAt: Date;
}

// Patient types
export interface Patient {
  id: string;
  registrationNumber: string;
  plhivNumber: string;
  patientName: string;
  fatherHusbandName?: string;
  contactNumber: string;
  address?: string;
  userId: string;
  medicines: PatientMedicine[];
  syncStatus: "Pending" | "Synced";
  syncedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface PatientMedicine {
  id: string;
  patientId: string;
  medicineName: string;
  quantity: number;
  isCustom: boolean;
  createdAt: Date;
}

// Medicine Inventory types
export interface MedicineInventory {
  id: string;
  medicineName: string;
  batchNumber: string;
  expiryDate: Date;
  openingBalance: number;
  receivedFromOffice: number;
  dailyConsumption: number;
  userId: string;
  syncStatus: "Pending" | "Synced";
  syncedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface MedicineInventoryWithCalculations extends MedicineInventory {
  availableBalance: number;
  daysToExpiry: number;
  isExpiringSoon: boolean; // 60-90 days
}

// Sync types
export interface SyncQueueItem {
  id: string;
  entityType: "patient" | "medicine";
  entityId: string;
  action: "create" | "update" | "delete";
  payload: Record<string, any>;
  syncStatus: "Pending" | "Synced" | "Failed";
  retryCount: number;
  lastError?: string;
  createdAt: Date;
  syncedAt?: Date;
}

// Master data types
export interface MasterMedicine {
  id: string;
  medicineName: string;
  category?: string;
  createdAt: Date;
}

export interface MasterArtCenter {
  id: string;
  centerName: string;
  googleSheetUrl?: string;
  createdAt: Date;
}

// Registration form types
export interface RegistrationFormData {
  artCenterName: string;
  fullName: string;
  email: string;
  designation: string;
  whatsappNumber: string;
}

export interface PatientFormData {
  registrationNumber: string;
  plhivNumber: string;
  patientName: string;
  fatherHusbandName?: string;
  contactNumber: string;
  address?: string;
  medicines: Array<{
    medicineName: string;
    quantity: number;
    isCustom: boolean;
  }>;
}

export interface MedicineInventoryFormData {
  medicineName: string;
  batchNumber: string;
  expiryDate: Date;
  openingBalance: number;
  receivedFromOffice: number;
  dailyConsumption: number;
}

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Sync status types
export interface SyncStatus {
  pendingCount: number;
  syncedCount: number;
  failedCount: number;
  lastSyncTime?: Date;
  isOnline: boolean;
  isSyncing: boolean;
}
